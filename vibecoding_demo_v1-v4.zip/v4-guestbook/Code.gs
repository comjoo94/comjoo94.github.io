/**
 * 실시간 강의실 방명록·투표판 — Google Apps Script 서버 코드
 *
 * 사용법
 * 1) 새 구글 시트 만들기 → 확장 프로그램 → Apps Script
 * 2) 이 코드 전체를 붙여넣고 저장(Ctrl+S)
 * 3) 함수 목록에서 setup 선택 → 실행 → 권한 승인 (시트 첫 줄에 머리글 생성)
 * 4) 배포 → 새 배포 → 유형: 웹 앱 → 실행 계정: 나 → 액세스 권한: 모든 사용자 → 배포
 * 5) 표시된 웹 앱 URL(…/exec)을 index.html의 API_URL에 붙여넣기
 *
 * 코드를 고친 뒤에는 배포 → 배포 관리 → 연필(수정) → 버전: 새 버전 → 배포
 * (그래야 같은 URL에 수정 내용이 반영된다)
 */

const SHEET_NAME = "방명록";
const HEADERS = ["시간", "전공", "난이도", "소감"];
const LEVELS = ["쉬움", "적당", "어려움"];
const MAX_ROWS_RETURNED = 200;

// 처음 한 번만 실행: 시트와 머리글 만들기
function setup() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_NAME);
  if (!sheet) sheet = ss.insertSheet(SHEET_NAME);
  sheet.getRange(1, 1, 1, HEADERS.length).setValues([HEADERS]).setFontWeight("bold");
  sheet.setFrozenRows(1);
}

function getSheet_() {
  // setup을 깜빡해도 시트가 없으면 자동으로 만든다
  if (!SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME)) setup();
  return SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

// 길이 제한 + 수식 주입 방지(=, +, -, @ 로 시작하면 앞에 작은따옴표)
function clean_(value, maxLen) {
  let s = String(value || "").trim().slice(0, maxLen);
  if (/^[=+\-@]/.test(s)) s = "'" + s;
  return s;
}

// 읽기(GET): 최근 글 목록을 JSON으로 돌려준다
function doGet() {
  const sheet = getSheet_();
  const last = sheet.getLastRow();
  if (last < 2) return json_({ ok: true, rows: [] });

  const start = Math.max(2, last - MAX_ROWS_RETURNED + 1);
  const values = sheet.getRange(start, 1, last - start + 1, HEADERS.length).getValues();
  const rows = values.map(r => ({
    time: r[0] instanceof Date ? r[0].toISOString() : String(r[0]),
    major: String(r[1]),
    level: String(r[2]),
    msg: String(r[3])
  }));
  return json_({ ok: true, rows: rows });
}

// 쓰기(POST): 한 줄 추가. 서버에서도 길이·값을 다시 검사한다
function doPost(e) {
  const lock = LockService.getScriptLock();
  lock.waitLock(10000); // 22명이 동시에 보내도 한 줄씩 차례로 기록
  try {
    const d = JSON.parse(e.postData.contents || "{}");
    const major = clean_(d.major, 20);
    const level = LEVELS.indexOf(d.level) >= 0 ? d.level : "적당";
    const msg = clean_(d.msg, 100);

    if (!major || !msg) return json_({ ok: false, error: "전공과 소감을 입력하세요." });

    getSheet_().appendRow([new Date(), major, level, msg]);
    return json_({ ok: true });
  } catch (err) {
    return json_({ ok: false, error: String(err) });
  } finally {
    lock.releaseLock();
  }
}
